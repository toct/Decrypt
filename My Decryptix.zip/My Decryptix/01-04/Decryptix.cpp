#include <iostream>

using namespace std;

int main();
int main()
{

	cout << "Decryptix Version 0.1\n";
	
	int round = 1;
	int howManyLetters = 0, howManyPositions  = 0;
	bool duplicatesAllowed = false;
	bool valid = false;

	const int minLetters = 2;
	const int maxLetters = 10;
	const int minPositions = 3;
	const int maxPositions = 10;

	while(!valid)
	{
		while(howManyLetters <minLetters || howManyLetters > maxLetters)
		{
			cout<<"How many letters? ( ";
			cout<< minLetters << "-" << maxLetters << "): ";
			cin >> howManyLetters;
			
			if(howManyLetters < minLetters || howManyLetters > maxLetters)
			{
				cout<< "please enter a number between ";
				cout<< minLetters << " and " << maxLetters << endl;
			}				
		}
		while(howManyPositions < minPositions || howManyPositions > maxPositions)
		{
			cout<<"How many positions? (";
			cout<<minPositions << "-" << maxPositions << "): ";
			cin>> howManyPositions;
			
			if(howManyPositions < minPositions || howManyPositions > maxPositions)
			{
				cout<< "please enter a number between ";
				cout<< minPositions << "and" << maxPositions << endl;
			}			
		}

		char choice = ' ';
		while(choice != 'y' && choice != 'n')
		{
			cout << "Allow duplicates (y/n)? ";
			cin>> choice;				
		}
	
		duplicatesAllowed = choice == 'y' ? true : false;
		if(!duplicatesAllowed && howManyLetters < howManyPositions)
		{
			cout <<"I can't put "<<howManyLetters;
			cout <<"letters in "<<howManyPositions;
			cout <<" positions without duplicates! Please try again.\n";
			
			howManyPositions = 0;
			howManyLetters = 0;
		}else
			valid = true;
	}
	return 0;
}

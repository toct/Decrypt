#include "Game.h"

#include <iostream>
using namespace std;

Game::Game():
	round(1),
	howManyPositions(0),
	howManyLetters(0),
	duplicatesAllowed(false)
{
	

cout << "In the Game constructor\n"<< endl;

	enum BoundedValues
	{
		minPos = 2,
		maxPos = 10,
		minLetters = 2,
		maxLetters = 26
	};

	bool valid = false;
	while(!valid){
		while(howManyLetters < minLetters ||howManyLetters > maxLetters)
		{
			cout<< "How Many Letters? (";
			cout<< minLetters << "-" << maxLetters << "): ";
			cin >> howManyLetters;
			if(howManyLetters < minLetters)
			{
				cout << "please enter a number between ";
				cout << minLetters << "and" << maxLetters << endl;
			}
		}
		while(howManyPositions < minPos || howManyPositions > maxPos){
			cout << "How many positions? (";
			cout << minPos <<"-"<<maxPos<<"): ";
			cin >> howManyPositions;
			if(howManyPositions < minPos || howManyPositions> maxPos)
			{
				cout<< "please enter a number ";
				cout<<minPos <<" and "<<maxPos<<endl;
			}
		}
		char choice = ' ';
		while(choice != 'y' && choice != 'n'){
			cout<< "Allow duplicates (y/n)? ";
			cin >> choice;
		}

		duplicatesAllowed = choice == 'y'?true:false;

		if(!duplicatesAllowed && howManyLetters < howManyPositions)
		{
			cout <<"I can't put "<<howManyLetters;
			cout <<"letters in "<<howManyPositions;
			cout <<" positions without duplicates! Please try again.\n";
			
			howManyPositions = 0;
			howManyLetters = 0;
		}else
			valid = true;
	}	
}
	Game::~Game()
	{
		cout << " In the Game destructor\n"<<endl;
	}

	void Game::Play()
	{

	}


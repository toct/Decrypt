class Game
{
	public:
		Game();
		~Game();
		void Play();
		
	
		bool duplicatesAllowed;
		int  howManyLetters;
		int  howManyPositions;
		int  round;
};

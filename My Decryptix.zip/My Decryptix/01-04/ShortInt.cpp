#include <iostream>
using namespace std;
int main(){
	short int smallNumber;
	smallNumber = 32767;
        cout<< "small nubmer:"<<smallNumber<<endl;
        smallNumber++;
        cout<< "small nubmer:"<<smallNumber<<endl;
        smallNumber++;
        cout<< "small nubmer:"<<smallNumber<<endl;
	return 0;
}

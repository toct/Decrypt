#include <iostream>
using namespace std;
int main(){
	unsigned short int smallNumber;
	smallNumber = 65535;
	cout<< "small nubmer:"<<smallNumber<<endl;	
	smallNumber++;
        cout<< "small nubmer:"<<smallNumber<<endl;
        smallNumber++;
        cout<< "small nubmer:"<<smallNumber<<endl;

	return 0;
}

#include <iostream>
#include "Game.cpp"

int main(){
	Game theGame;
	return 0;
}


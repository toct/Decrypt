#include <iostream>
using namespace std;
int main(){
	char myString[80];

	strcpy(myString,"Hello there");

	cout<< "myString is "<<strlen(myString) << " charaters long!" << endl;
	cout<<" myString :" << myString << endl; 

	char c1 = myString[1];
	char c2 = *(myString + 1);
	cout<< "c1: "<<c1<<" c2: "<<c2 <<endl;

	char *p1 = myString;
	char *p2 = myString + 1;
	cout<< "p1: " <<p1 <<endl;
	cout<< "p2: "<<p2 <<endl;

	cout<< "myString + :"<< myString + 1<<endl;

	myString[4] = 'a';
	cout<< "myString: "<< myString << endl;

	*(myString + 4) = 'b';
	cout << "myString : "<< myString << endl;


	p1[4] = 'c';
	cout<< "myString: "<< myString << endl;

	*(p1 + 4) = 'd';
 	cout<< "myString: "<< myString << endl;
	
	myString[4] = 'o';
	myString[5] = '\0';
	cout<< "myString: "<<myString<<endl;
	
	


	return 0;
}

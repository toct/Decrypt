#include <iostream>

using namespace std;

class Game{
	public:
		Game(){};
		~Game(){};
		void Play();
		void Score(int *correct, int *position);

	private:
		int howManyLetters;
		int howManyPositions;

};
void Game::Score(int *correct, int *position){
	cout<<"\nBeginning score, Correct: ";
	cout<< *correct << " Position: " << *position <<endl;
	*correct = 5;
	*position = 7;
        cout<<"Departing score, Correct: ";
        cout<< *correct << " Position: " << *position <<endl;

}

void Game::Play(){
	int correct = 0;
	int position = 0;

	cout<< "Beginning Play. Correct: ";
	cout<< correct << " Position: " << position << endl;
	correct = 2;
	position = 4;

        cout<< "Play updated values. Correct: ";
        cout<< correct << " Position: " << position << endl;


	cout<<"\n Calling score ... " << endl;
	Score(&correct,&position);

        cout<< "\nBack form Score() in Play. Correct: ";
        cout<< correct << " Position: " << position << endl;

}

int main()
{
	Game theGame;
	theGame.Play();
	return 0;

}


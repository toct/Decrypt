#ifndef DEFINED

#define DEFINED

#include <iostream>
using namespace std;

const char alpha[] = "abcdefghigklmnopqrstuvwxyz";
const int minPos = 2;
const int maxPos = 10;
const int minLetters = 2;
const int maxLetters = 26;

#define DEBUG
#ifndef DEBUG
	#define ASSERT(x);
#else
	#define ASSERT(x) \
		if(!(x)) \
		{ \
			cout<< "ERROR!!  Assert " << #x << " failed\n"; \
			cout<< "on line " << __LINE__ <<"\n"; \
			cout << "in file" <<__FILE__ << "\n"; \
		}

#endif

#endif


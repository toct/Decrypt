#include "LinkList.cpp"
#include "def0514.h"

int main();
int main(){
	Node header('a');
	header.Insert('b');

	int count = header.HowMany('a');
	cout<<"There are "<< count << "  instances of a\n";

        count = header.HowMany('b');
        cout<<"There are "<< count << "  instances of b\n";

	cout<<"\n\nHere's the entire list: ";
    header.Display();
cout<<endl;
}


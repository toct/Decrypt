#include "LinkList.h"
#include <iostream>
using namespace std;

Node::Node(char c):
myChar(c),nextNode(0)
{
    cout<<"In constructor of Node("<<this <<")\n";
}

Node::~Node(){
    cout<<"In constructor of Node("<<this <<")\n";

	if(nextNode)
	{
		delete nextNode;
	}
}

void Node::Display() const
{
	cout<< myChar;
	if(nextNode)
	{
		nextNode->Display();
	}
}

int Node::HowMany(char c) const
{
     int myCount = 0;
	if(myChar == c)
	{
		myCount ++;
	}
	if(nextNode)
	{
		return myCount + nextNode->HowMany(c);
	}
	else
    {
		return myCount;
    }
}

void Node::Insert(char c)
{
	if(!nextNode)
	{
		nextNode = new Node(c);
	}
	else
	{
		nextNode->Insert(c);
	}
}

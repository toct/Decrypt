#include "LinkList.cpp"
#include "def0514.h"

int main();
int main(){
    Node *pHead = snew Node('a');
	pHead->Insert('b');
    pHead ->Insert('c');
    pHead ->Insert('b');
    pHead ->Insert('b');


	int count = pHead->HowMany('a');
	cout<<"There are "<< count << "  instances of a\n";

        count = pHead->HowMany('b');
        cout<<"There are "<< count << "  instances of b\n";

	cout<<"\n\nHere's the entire list: ";
    pHead->Display();
    cout<<"\n\nDeleteing pHead...."<<endl;
    delete pHead;
    return 0;
}


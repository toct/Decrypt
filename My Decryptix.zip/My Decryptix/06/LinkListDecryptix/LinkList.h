#ifndef NODE_H
#define NODE_H


class Node{
	public:
	Node(char c);
	~Node();
	void Display() const;
	int HowMany(char c) const;
	void Insert(char c);

    
    Node *	GetNext		() { return nextNode; }
    char	GetChar		() { return myChar; }
    
    
    
	private:
	

	char myChar;
	Node * nextNode; 
};

#endif

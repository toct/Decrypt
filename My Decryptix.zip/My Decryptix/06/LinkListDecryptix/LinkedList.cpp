#include "LinkedList.h"
#include "def0514.h"
#include "LinkList.cpp"
LinkedList::LinkedList():headNode(0)
{}

LinkedList::~LinkedList()
{
	if ( headNode )
		delete headNode;
}

bool LinkedList::Add(char theChar, bool dupes)
{
	bool inserted = false;

	if ( ! headNode )
	{
		headNode = new Node(theChar);
		inserted = true;
	}
	else if ( dupes || HowMany(theChar) == 0 )
	{
		headNode->Insert(theChar);
		inserted = true;
	}

	return inserted;
}

int LinkedList::HowMany(char theChar) const
{
	return headNode->HowMany(theChar);
}

char LinkedList::operator[](int offSetValue)
{
	Node * pNode = headNode;
	for ( int i = 0; i < offSetValue && pNode; i++ )
		pNode = pNode->GetNext();

	ASSERT ( pNode );
	char c =  pNode->GetChar();
	return c;
}


#ifndef LinkedList_h

#define LinkedList_h

#include "LinkList.h"

class LinkedList
{
public:
	LinkedList();
	~LinkedList();
	bool	Add			(char c, bool dupes = true);
	void	Display		()	const { headNode->Display(); }
	int		HowMany		(char c)	const;
	char	operator[]	(int offset);
    
private:
	Node *	headNode;
};

#endif

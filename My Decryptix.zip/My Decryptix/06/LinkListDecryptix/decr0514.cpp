
#include "game0514.cpp"

int main()
{
	cout << "Decryptix. (c)Copyright 1999 Liberty Associates, Inc. Version 0.3\n\n" << endl;
	bool playAgain = true;

	while ( playAgain )
	{
		char choice = ' ';
		Game theGame;
		theGame.Play();

		cout << "\nThe answer: ";
//		theGame.Display(theGame.GetSolution());
        theGame.GetSolution().Display();
		cout << "\n\n" << endl;

		while ( choice != 'y' && choice != 'n' )
		{
			cout << "\nPlay again (y/n): ";
			cin >> choice;
		}

		playAgain = choice == 'y' ? true : false;
	}

	return 0;
}


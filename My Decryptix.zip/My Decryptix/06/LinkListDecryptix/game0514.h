#ifndef GAME_H
#define GAME_H

#include "def0514.h"
#include "LinkedList.h"
class Game{
	public:
		Game();
    ~Game(){};
		void Display(const char * charArray) const
		{
			cout<< charArray;
		}
		void Play();
		const LinkedList GetSolution() const{ return solution; }
		void Score(const char * thisGuess, int &correct, int & position);

	private:
		int HowMany(const char *, char);
		LinkedList solution;
		int howManyLetters;
		int howManyPositions;
		int round;
		bool duplicates;
};

#endif

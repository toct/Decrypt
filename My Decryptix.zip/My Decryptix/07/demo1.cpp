#include <iostream>
using namespace std;

class Point
{
	public:
		Point(int x, int y):itsX(x),itsY(y){}
        ~Point(){}
        int GetX() const{return itsX;}
        int GetY() const{return itsY;}

	private:
		int itsX;
		int itsY;
};

class Rectangle
{
	public:
		Rectangle():itsWidth(5),itsHeight(7){}
		Rectangle(int side):itsWidth(side),itsHeight(side){}
		Rectangle(int width, int height): itsWidth(width), itsHeight(height){}
		Rectangle(Point upperLeft, Point lowwerRight);
		~Rectangle(){}
		int GetWidth() const {return itsWidth;}
		int GetHeight() const {return itsHeight;}
	private:
		int itsWidth;
		int itsHeight;
};

Rectangle::Rectangle(Point upperLeft, Point lowwerRight):itsWidth(lowwerRight.GetX() - upperLeft.GetX()), itsHeight(lowwerRight.GetY() - upperLeft.GetY()){}


int main(){
	Point u1(5,5);
	Point lr(20,15);

	Rectangle r1;
	Rectangle r2(3);
	Rectangle r3(7,12);
	Rectangle r4(u1,lr);

    cout<< "r1: "<< r1.GetWidth() << "x" << r1.GetHeight() << endl;
    cout<< "r2: "<< r2.GetWidth() << "x" << r2.GetHeight() << endl;
    cout<< "r3: "<< r3.GetWidth() << "x" << r3.GetHeight() << endl;
    cout<< "r4: "<< r4.GetWidth() << "x" << r4.GetHeight() << endl;
}



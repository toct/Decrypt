#include <iostream>
using namespace std;

class Point
{
	public:
		Point(int x, int y);
		Point(const Point & rhs);
        ~Point()
	{
		cout<< "In Point destructor (";
		cout << this << ")"<< endl; 
	}
	void SetX(int x){itsX = x;}
	void SetY(int y){itsY = y;}
        int GetX() const{return itsX;}
        int GetY() const{return itsY;}

	private:
		int itsX;
		int itsY;
};

class Rectangle
{
	public:
//		Rectangle(const Rectangle & rhs);
		Rectangle(int top, int left, int bottom, int right);
		~Rectangle()
		{
                	cout<< "In Rectangle destructor (";
                	cout << this << ")"<< endl;
	
			delete itsUpperLeft;
			delete itsLowerRight;
		}
		Point *GetUpperLeft() const {return itsUpperLeft;}
		Point *GetLowerRight() const {return itsLowerRight;}

		int GetDepth() const {return itsDepth;}

		int GetWidth() const;
		int GetHeight() const;
		int GetArea() const;
	private:
		Point *itsUpperLeft;
		Point *itsLowerRight;
		
		int itsDepth;
};


int GetArea(Rectangle r)
{
	cout<< "\nIn GetArea()..."<<endl;
	return r.GetArea();
}

int GetAreaByRef(const Rectangle & rectRef)
{
	cout<< "In GetAreaByRef(const Rectangle &)..."<<endl;
	return rectRef.GetArea();
}

int GetAreaByRef(const Rectangle * const Prect)
{
	cout<< "In GetAreaByRef(const Rectangle * const Prect)"<<endl;
	return Prect ->GetArea();
}

Rectangle::Rectangle(int top, int left, int bottom, int right):itsUpperLeft(new Point(left, top)),itsLowerRight(new Point(right, bottom))
{
	cout<<"In rectangle constructor("<<this<<")\n"<<endl;
}
/*
Rectangle::Rectangle(const Rectangle & rhs):itsLowerRight(rhs.GetLowerRight()),itsUpperLeft(rhs.GetUpperLeft()),itsDepth(rhs.GetDepth())
{
	cout<< "In Rectangle copy constructor("<<this<<")\n"<<endl;
}
*/
int Rectangle::GetWidth() const
{
	int rightX = itsLowerRight ->GetX();
	int leftX = itsUpperLeft->GetX();
	int  width = rightX - leftX;

	cout<< "GetWidth. rightX: "<<rightX;	
	cout<< "leftX:  "<< leftX<<". WidthL:  "<< width <<endl;
}


int Rectangle::GetHeight() const
{
        int topY = itsLowerRight->GetY();
        int bottomY = itsUpperLeft->GetY();
        int height = topY - bottomY;
	
	cout<<"GetHeight. topY: "<<topY<< "bottomY: ";
        cout<< bottomY  <<". Height:  "<< height <<endl;
}

int Rectangle::GetArea() const
{
	int Width = GetWidth();
	int Height = GetHeight();
	return (Width * Height);
}

Point::Point(int x, int y):itsX(x),itsY(y)
{
	cout<< "In Point constructor(";
	cout<<this<<")"<<endl;
}
Point::Point(const Point & rhs):itsX(rhs.GetX()),itsY(rhs.GetY())
{
	cout<< "In Point copu constructor ("<<this<<")"<<endl;
}


int main()
{
	cout<< "Consturcting the rectangle..."<<endl;
	
	Rectangle r1(100, 20, 50, 80);


	cout<<"\nCalling GetArea()..."<<endl;
	cout<<"r1 area: "<< GetArea(r1);
	cout<<"\n"<<endl;

	
	cout<<"Calling GetAreaByRef(const Rectangle &)..."<<endl;
	cout<<"r1 area: "<< GetAreaByRef(r1);
	cout<<"\n"<<endl;


	cout<<"Calling GetAreaByRef(const Rectangle * const)..."<<endl;
	cout<<"r1 Area: "<<GetAreaByRef(& r1)<<"\n"<<endl;
	
	return 0;
}
	





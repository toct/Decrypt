#include "def0514.h"
#include "Game.cpp"
int main()
{
	cout<< "Decryptix. (c)Copyright 1999 Liberty Associates,";
	cout<< "Inc. Version 0.3\n\n"<<endl;


	bool playAgain = true;
	while(playAgain)
	{
		char choice = ' ';
		Game theGame;
		theGame.Play();
		
		cout<<"\nThe anwser: ";
		theGame.GetSolution().Display();
		cout<< "\n\n"<<endl;
	
		while(choice != 'n' && choice != 'y')
		{
			cout<< "\nPlay again (y/n): ";
			cin >> choice;
		}
		playAgain = choice == 'y'?true:false;
	}
	return 0;
}

#include "LinkedList.h"

InternalNode::InternalNode(char theCharacter, Node *node):myChar(theCharacter),nextNode(node){}

InternalNode::~ InternalNode()
{
	delete nextNode;
}

void InternalNode::Display() const
{
	cout << myChar; nextNode->Display();
}

int InternalNode::HowMany(char c) const
{
	int myCount = 0;
	if(myChar == c)
		myCount ++;
	
	return myCount + nextNode->HowMany(c);
}

Node * InternalNode::Insert(char theCharacter)
{
	nextNode = nextNode->Insert(theCharacter);
	return this;
}

char InternalNode::operator[](int offset)
{
	if(offset == 0)
		return myChar;
	else
		return (*nextNode)[--offset];	
}

int TailNode::HowMany(char c) const
{
	return 0;
}

Node * TailNode::Insert(char theCharacter)
{
	return new InternalNode(theCharacter, this);
}

char TailNode::operator[](int offset)
{
	ASSERT(false);
	return ' ';
}

LinkedList::LinkedList():duplicates(true)
{
	nextNode = new TailNode;
}

LinkedList::~LinkedList()
{
	delete nextNode;
}

void LinkedList::Display() const
{
	nextNode->Display();
}

int LinkedList::HowMany(char c) const
{
	return nextNode->HowMany(c);
}

char LinkedList::operator[](int offset)
{
	return (*nextNode)[offset];
}

Node * LinkedList::Insert(char theCharacter)
{
	nextNode = nextNode->Insert(theCharacter);
	return nextNode;	
}

bool LinkedList::Add(char c)
{
	if(duplicates || HowMany(c) == 0)
	{	
		Insert(c);
		return true;
	}else
		return false;
}

void LinkedList::SetDuplicates(bool dupes)
{
	duplicates = dupes;
}

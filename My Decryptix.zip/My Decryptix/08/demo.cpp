#include <iostream>
using namespace std;

class Base{
	public:
		Base(){cout<< "Base constructor\n";}
		
		virtual  ~Base(){cout<<"Base destructor\n";}
		
	 void MethodOne(){cout<< "Base MethodOne\n";}
		virtual void MethodTwo(){cout<< "Base MethodTwo\n";}
		virtual void MethodThree(){cout<<"Base MethodeThree\n";}

	private:
};

class Derived : public Base{

	public:
		Derived(){cout<< "Derived constructor\n";}

		virtual ~Derived(){cout<<"Derived destructor\n";}
		 void MethodOne(){cout<<"Derived MethodOne\n";}
		virtual void MethodTwo(){cout<<"Derived MethodTwo\n";}
		virtual void MethodThree(int myParam){cout<<"Derived MethodThree\n";}

	private:
};

int main(){

	Base *pb = new Base;
	pb->MethodOne();
	pb->MethodTwo();
	pb->MethodThree();

	delete pb;
	cout<<endl;


	Base *pbd = new Derived();
	pbd->MethodOne();
        pbd->MethodTwo();
        pbd->MethodThree();
	delete pbd;
        cout<<endl;
                                                 
	Derived *pd = new Derived();
        pd->MethodOne();
        pd->MethodTwo();
//        pd->MethodThree();
	pd->MethodThree(5);
        delete pd;
        cout<<endl;
	
}

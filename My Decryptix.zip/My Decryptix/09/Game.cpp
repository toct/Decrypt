#include "Game.h"

#include "def0514.h"
#include <time.h>
#import "Guess.cpp"
#import "LinkedList.h"
Game::Game():round(10), howManyPositions(0),howManyLetters(0), hintCtr(0),duplicates(false)
{
	bool valid  = false;
	while(!valid)
	{
		while(howManyLetters < minLetters || howManyLetters > maxLetters)
		{
			cout<< "How many letters? (";
			cout<< minLetters <<" - " <<maxLetters <<"): ";
			cin >> howManyLetters;
			if(howManyLetters < minLetters || howManyLetters > maxLetters)
			{
				cout<<"please enter a number between ";
				cout<< minLetters << " and "<<maxLetters<<endl;
			}
		}

		while(howManyPositions < minPos || howManyPositions > maxPos)
		{
			cout<< "How many positions? (";
			cout<< minPos <<" - "<<maxPos<<"): ";
			cin >> howManyPositions;
			if(howManyPositions < minPos || howManyPositions > maxPos)
			{
				cout<<"please enter a number between ";
				cout<< minPos<<" and "<<maxPos<<endl; 
			}
		}
		
		char choice = ' ';
		while(choice != 'y' && choice != 'n')
		{
			cout<< "Allow  duplicates (y/n)? ";
			cin >> choice;
		}
		
		duplicates = choice== 'y'?true:false;
		solution.SetDuplicates(duplicates);
		
		if(!duplicates && howManyPositions > howManyLetters )
		{
			cout<< "I can't put "<< howManyLetters << " letters in "<<howManyPositions <<" positions without duplicates! Please try again.\n";
			howManyLetters = 0;
			howManyPositions = 0;
			
		}else
			valid = true;
	}

	srand((unsigned)time(NULL));//srand函数是随机数发生器(rand())的初始化函数
	for(int i = 0; i< howManyPositions;)
	{
		int nextValue = rand()%(howManyLetters);
		char theChar = alpha[nextValue];
		if(solution.Add(theChar))
			i++;
	}
}

void Game::DisplayAnswer()
{
	solution.Display();
}

const LinkedList<char> & Game:: GetSolution() const
{
	return solution;
}

inline int Game::HowMany(const char * theString, char theChar)
{
	int count = 0;
    for(int i = 0; i< strlen(theString); i++)
		if(theString[i] == theChar)
			count++;
	return count;
	
}

bool Game::IsValid(char c) const
{
	bool valid = false;
	for(int i = 0; i< howManyLetters; i++)
		if(alpha[i] == c)
			valid = true;
	return valid;
}

void Game::Play()
{
	char guess[80];
	int correct = 0;
	int position = 0;
	bool quit = false;
	
	while(position < howManyPositions)
	{
		cout<< "\nRound "<<round <<". Enter -? or";
		cout << howManyPositions << "letters between ";
		cout<<alpha[0]<<" and ";
		cout<<alpha[howManyLetters-1]<<": ";

		cin>> guess;
		
		if(guess[0] == '-')//got a flag
		{
			quit = HandleFlag(guess[1]);
			if(quit)
				break;
			continue;
		}
		
		if(strlen(guess) < howManyPositions)
		{
			cout<< "\n ** Please enter exactly ";
			cout<< howManyPositions << " letters. **\n";
			continue;
		}
	
		round++;

		cout<< "\nYour guess: " << guess <<endl;

		Score(guess, correct, position);
		cout<<"\t\t" <<correct << " correct, ";
		cout<<position << " in position."<< endl;

		Guess thisRound(guess, correct, position);
		history.Add(thisRound);
	}

	if(!quit)
	{
		cout<< "\n\nCongratulations! It took you ";
		if(round <= 6)
			cout<<"only";
		if(round -1 == 1)
			cout<<"one round!"<<endl;
		else
			cout<< round - 1 << " rounds."<<endl;
	}
}	

void Game::Score(const char * thisGuess, int & correct, int & position)
{
	correct = 0;
	position = 0;
	int i;
	for(i = 0; i< howManyLetters; i++)
	{
		int howManyInGuess = HowMany(thisGuess, alpha[i]);
		int howManyInAnswer = solution.HowMany(alpha[i]);
		correct += howManyInGuess< howManyInAnswer?howManyInGuess:howManyInAnswer;
	}

	for(i = 0; i< howManyPositions; i++)
	{
		if(thisGuess[i] == solution[i])
			position++;
	}	

	ASSERT(position <= correct)	
}

void Game::ShowHistory()
{
	history.Display();
}

void Game::ShowHint()
{
	if(hintCtr < howManyPositions)
	{
		cout<< "\nHINT!! Position "<<hintCtr+1;
		cout<<": "<<solution[hintCtr]<<endl;
		hintCtr++;
	}
}

void Game::ShowHelp()
{
	cout<< "\t-h Hint\n\t-s Show history\n";
	cout<< "\t-? Help\n\t-q quit\n" <<endl;
}

bool Game::HandleFlag(char flag)
{
	bool quit = false;
	switch(flag)
	{
		case 'h':
			ShowHint();
			break;
                case 's':
                        ShowHistory();
                        break;                
                case '?':
                        ShowHelp();
                        break;		
                case 'q':
                        quit = true;
                        break;	
		default:
			cout<< "\nUnknown flag. Ignored.\n";
			break;
	}
	return quit;
}





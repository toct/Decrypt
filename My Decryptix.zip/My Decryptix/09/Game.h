#ifndef GAME_H
#define GAME_H

#include "def0514.h"
#include "Guess.h"
#include "LinkedList.h"
class Game
{
	public:
		Game();
		~Game(){}
		void Play();
		bool IsValid(char c) const;
		const LinkedList<char>  & GetSolution() const;
		void DisplayAnswer();
		
		void Score(const char * thisGuess, int & corect, int & position);
		bool HandleFlag(char flag);
		void ShowHint();
		void ShowHistory();
		void ShowHelp();
		
	private:
		int HowMany (
                     const char * theString,
                     char theChar
                     );
		LinkedList<char> solution;
		LinkedList<Guess>history;

		int howManyLetters;
		int howManyPositions;
		int round;
		int hintCtr;
		bool duplicates;
};
#endif

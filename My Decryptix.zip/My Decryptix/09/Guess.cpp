#include "Guess.h"
#import "Score.cpp"
Guess::Guess(const char * guess, int howManyRight, int howManyInPosition):theScore(howManyRight, howManyInPosition)
{
	int len = strlen(guess);
	string = new char[len + 1];
	strcpy(string, guess);
}


Guess::Guess(const Guess & rhs):theScore(rhs.theScore)
{
	int len = strlen(rhs.string);
	string = new char[len + 1];
	strcpy(string, rhs.string);
}

Guess::Guess():string(0)
{}

Guess::~Guess()
{
	if(string)
		delete string;
}

bool Guess::operator==(const Guess &rhs) const
{
	return (strcmp(string, rhs.string) == 0 || theScore == rhs.theScore);
}

Guess & Guess::operator=(const Guess & rhs)
{
	if( this != &rhs)
	{
		theScore = rhs.theScore;
		int len = strlen(rhs.string);
		string = new char[len + 1];
		strcpy(string, rhs.string);
	}
	return *this;
}

ostream & operator<<(ostream & ostr, const Guess & theGuess)
{
    ostr<<theGuess.GetString()<<"\t";
    ostr<<theGuess.GetScore().GetCorrect();
    ostr<<" correct, ";
    ostr<<theGuess.GetScore().GetInPosition();
    ostr<<" in position\n";
    return ostr;
}

#ifndef GUESS_H
#define GUESS_H

#include "def0514.h"
#include "Score.h"

class Guess{
	public:
		Guess();
		Guess(const char * guess, int howManyRight, int howManyInPosition);
        Guess(const Guess & rhs);
		~Guess();
		const Score & GetScore() const{return theScore;}
		const char * GetString() const{return string;}
		friend ostream & operator<<(ostream & ostr, const Guess & theGuess);
		bool operator ==( const Guess & rhs) const;
		Guess &operator=(const Guess &	rhs);
	private:
		char * string;
		Score theScore;
};
#endif

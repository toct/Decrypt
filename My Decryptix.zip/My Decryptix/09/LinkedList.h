#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "def0514.h"



template <class T>
class Node  //abstract class
{
	public:
		Node(){}
		virtual ~Node(){}
        virtual void Display() const{};
		virtual int HowMany(const T & theData) const = 0;//纯虚函数 virtual =0
		virtual Node<T> * Insert(const T & theData) = 0; //Node<T>代表链表中的元素是一个抽象类型，在实例化时确定它的类型。
		virtual const T & operator[](int offset) = 0;
	private:
};
/*
 在什么情况下使用纯虚函数(pure vitrual function)?  ,virtual =0
 1，当想在基类中抽象出一个方法，且该基类只做能被继承，而不能被实例化；
 2，这个方法必须在派生类(derived class)中被实现；
 如果满足以上两点，可以考虑将该方法申明为pure virtual function.
*/
template <class T>
class InternalNode:public Node<T>
{
	public:
		InternalNode(const T& theData, Node<T> *next);
		~InternalNode();
		virtual void Display() const;
		virtual int HowMany(const T & theData) const;
		virtual Node<T> * Insert(const T& theData);
		virtual const T& operator[](int offset);
	private:
		T myData;
		Node<T> *nextNode;
};

template<class T>
class TailNode:public Node<T>
{
	public:
		TailNode(){}
		~TailNode(){}
		virtual int HowMany(const T& data)const;
		virtual Node<T> * Insert(const T& data);
		virtual const T& operator[](int offset);
	private:
		
};

template<class T>
class LinkedList:public Node<T>
{
	public:
		LinkedList();
		~LinkedList();
		virtual void Display() const;
		virtual int HowMany(const T & data) const;
		virtual const T & operator[](int offset);

		bool Add(const T& data);
		void SetDuplicates(bool dupes);

	private:
		Node<T> *Insert(const T& data); //继承父类中的public:方法，定义为私有。
		bool duplicates;
		Node<T> *nextNode;
};

template<class T>
Node<T> * InternalNode<T>::Insert(const T& theData)
{
	nextNode = nextNode->Insert(theData);
	return this;
}

template<class T>
const T & InternalNode<T>::operator[](int offset)
{
	if(offset == 0)
		return myData;
	else
		return (*nextNode)[--offset];
}

template<class T>
InternalNode<T>::InternalNode(const T& theData, Node<T> * next):myData(theData),nextNode(next)
{	
}

template<class T>
InternalNode<T>::~InternalNode()
{
	delete nextNode;
}

template<class T>
void InternalNode<T>::Display() const
{
	cout<<myData;nextNode->Display();
}

template<class T>
int InternalNode<T>::HowMany(const T& thedata) const
{
	int myCount = 0;
	if(thedata == myData)
		myCount++;
	return myCount + nextNode->HowMany(thedata);
}

template<class T>
Node<T> * TailNode<T>::Insert(const T& data)
{
	return new InternalNode<T>(data,this);
}

template<class T>
const T & TailNode<T>::operator[](int offset)
{
	ASSERT(false);
	T *pt = new T;
	return *pt;//memory leak but can't get here;
}

template<class T>
int TailNode<T>::HowMany(const T& thedata) const
{
	return 0;
}

template<class T>
LinkedList<T>::LinkedList():duplicates(false)
{
	nextNode = new TailNode<T>;
}

template<class T>
LinkedList<T>::~LinkedList()
{
	delete nextNode;
}

template<class T>
void LinkedList<T>::Display() const
{
	nextNode->Display();
}


template<class T>
int LinkedList<T>::HowMany(const T& theData) const
{
	return nextNode->HowMany(theData);
}

template<class T>
Node<T> *LinkedList<T>::Insert(const T & theData)
{
	nextNode = nextNode->Insert(theData);
	return nextNode;
}

template<class T>
const T & LinkedList<T>::operator[](int offset)
{
	return (*nextNode)[offset];
}

template<class T>
bool LinkedList<T>::Add(const T & theData)
{
	if(duplicates || HowMany(theData) == 0)
	{
		Insert(theData);
		return true;
	}else
		return false;
}

template<class T>
void LinkedList<T>::SetDuplicates(bool dupes)
{
	duplicates = dupes;
}





#endif

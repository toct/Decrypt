#include "Score.h"

Score::Score(int right, int pos):
howManyInPosition(pos),
howManyRight(right)
{}


Score::Score():
howManyInPosition(0),
howManyRight(0)
{}

Score::Score(const Score & rhs):
howManyInPosition(rhs.howManyInPosition),
howManyRight(rhs.howManyRight)
{}


Score::~Score()
{}

int Score::GetInPosition() const
{
	return howManyInPosition;
}


int Score::GetCorrect() const
{
	return howManyRight;
}

bool Score::operator==(const Score& rhs) const
{
	return howManyInPosition == rhs.howManyInPosition &&
		howManyRight == rhs.howManyRight;
}

Score & Score::operator=(const Score& rhs)
{
	if ( rhs == *this )
		return *this;

	howManyInPosition = rhs.howManyInPosition;
	howManyRight = rhs.howManyRight;
	return *this;
}



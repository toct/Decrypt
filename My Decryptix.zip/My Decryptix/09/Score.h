#ifndef SCORE_H
#define SCORE_H

class Score
{
	public:
		Score(int right, int pos);
		Score();
		Score(const Score & rhs);
		virtual ~Score();
		int GetInPosition() const;
		int GetCorrect() const;
		bool operator == (const Score & rhs) const;
		Score & operator=(const Score & rhs);
	private:
		int howManyInPosition;
		int howManyRight;
};
#endif

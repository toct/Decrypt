#ifndef DEFINED

#define DEFINED

#include <iostream>


//
#include <vector>
#include <iterator>
#include <algorithm>
#include <time.h>
#include <utility>
//



using namespace std;

const char alpha[] = "abcdefghigklmnopqrstuvwxyz";
const int minPos = 2;
const int maxPos = 10;
const int minLetters = 2;
const int maxLetters = 26;



//
const int SecondsInMinute = 60;
const int SecondsInHour = SecondsInMinute * 60;
const int SecondsInDay = SecondsInHour * 24;
const int GUESSES_PER_SECOND = 10000;

const int szInt =  sizeof(int);
const int szChar = sizeof(char);
const int szBool = sizeof(bool);
//



#define DEBUG
#ifndef DEBUG
	#define ASSERT(x);
#else
	#define ASSERT(x) \
		if(!(x)) \
		{ \
			cout<< "ERROR!!  Assert " << #x << " failed\n"; \
			cout<< "on line " << __LINE__ <<"\n"; \
			cout << "in file" <<__FILE__ << "\n"; \
		}

#endif

#endif


#include "def0514.h"

#include "Game.cpp"
#include "Guess.cpp"


int main()
{
	cout << "Decryptix. (c)Copyrihgt 1999";
	cout << " Liberty Associates, Inc.";
	cout << "Version 10\n\n" << endl;

	bool playAgain = true;

	while(playAgain)
	{
		char choice = ' ';
		Game * g = new Game;
		g->Play();

		cout << "\nThe answer: ";
		g->Display(g->GetSolution());
		cout << "\n\n" << endl;

		delete g;//important 

		while(choice != 'n' && choice != 'y')
		{
			cout << "\nPlay again (y/n): ";
			cin >> choice;
		}

		playAgain = choice == 'y'?true:false;
	}
	return 0;
}

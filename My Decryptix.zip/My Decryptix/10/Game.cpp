#include "Game.h"
#include "def0514.h"

#include <string>
#include <ctime>
#include <algorithm>

Game::Game():hintCtr(0),howManyLetters(0),howManyPositions(0),duplicates(false),round(1)
{
	bool valid = false;
	while(!valid)
	{
		while(howManyLetters < minLetters || howManyLetters > maxLetters)
		{
			cout<<"How many Letters? (";
			cout<< minLetters <<" - "<<maxLetters<<"): ";
			cin >> howManyLetters;
			if(howManyLetters < minLetters || howManyLetters > maxLetters)
			{
				cout<<"please enter a number between ";
				cout<<minLetters <<" and "<< maxLetters <<endl;
			}
		}

		while(howManyPositions < minPos || howManyPositions > maxPos)
		{
			cout<<"How many positions? (";
			cout<<minPos<< " - " <<maxPos<<"): ";
			cin >> howManyPositions;
			if(howManyPositions < minPos || howManyPositions > maxPos)
			{
				cout<<"please enter a number ";
				cout<<minPos<<" and "<< maxPos<<endl;
			}
		}

		char choice = ' ';
		while(choice != 'n' && choice != 'y')
		{
			cout<<"Allow duplicates (y/n)? ";
			cin >> choice;
		}
		duplicates = choice == 'y'?true:false;
		if(!duplicates && howManyPositions > howManyLetters)
		{
			cout<< "I can't put "<< howManyLetters;
			cout<<" letters in "<< howManyPositions;
			cout<<" pisitions without duplicates! Please try again.\n";

			howManyLetters = 0;
			howManyPositions = 0;
		}else
			valid = true;
	}

    srand((unsigned)time(NULL));
	for(int i = 0; i < howManyPositions;)
	{
		int nextValue = rand()%(howManyLetters);
		char theChar = alpha[nextValue];
		if(!duplicates && i > 0)
		{
			vector<char>::iterator where = find(solution.begin(),solution.end(), theChar);
			if(where != solution.end())
				continue;
		}
		solution.push_back(theChar);
		i++;
	}

}

void Game::Display(vector<char> charVec) const
{
	copy(
		charVec.begin(),
		charVec.end(),
		ostream_iterator<char>(cout," ")		
         );
}

bool Game::IsValid(char c) const
{
	bool isValid = false;
    for(int i = 0 ; i < howManyLetters ; i++)
		if(alpha[i] == c)
			isValid = true;
	return isValid;
}

void Game::Play()
{
	vector<char> thisGuess;
	int correct = 0;
	int position = 0;
	bool quit = false;
	
	while(position < howManyPositions)
	{
		thisGuess.clear();
		string guess;
		
		cout<< "\n Round "<< round << ". Enter -? or " << howManyPositions;
		cout<< " letters between " << alpha[0] << " and " << alpha[howManyLetters - 1] << ": ";
		cin >> guess;
		
		if(guess[0] == '-')//got a flag
		{
			quit = HandleFlag(guess[1]);
			if(quit)
				break;
			continue;	
		}

		if(guess.length() < howManyPositions)
		{
			cout<< "\n ** Please enter exactly ";
			cout << howManyPositions << " letters. **\n";
			continue;
		}

		bool lineIsValid = true;
		for(int i = 0; i< howManyPositions ; i++)
		{
			lineIsValid = IsValid(guess[i]);
			if(!lineIsValid)
				break;
		}
		
		if(lineIsValid)
			for(int i = 0; i< howManyPositions; i++)
				thisGuess.push_back(guess[i]);
		else
		{
			cout<< "Please enter only letter between ";
			cout<< alpha[0] << " and " << alpha[howManyLetters - 1] << "\n";
			continue;
		}

		round ++;
		
		cout << "\n Your guess: ";
		Display(thisGuess);
		
		Score(thisGuess, correct, position);
		cout << "\t\t" <<correct << " correct, ";
		cout << position << " in position." << endl;

		Guess thisRound(thisGuess, correct, position);
		history.push_back(thisRound);
	}
	if(!quit)
	{
		cout << "\n\n Congratulations! It took you ";
		if(round <= 6)
			cout << "only ";
		if(round - 1 == 1)
			cout << "one round!" << endl;
		else
			cout<< round - 1 << " rounds. " <<endl;
	}
}

vector<char> Game::GetSolution() const
{
	return solution;
}

bool Game::HandleFlag(char flag)
{
	bool quit = false;
	switch(flag)
	{
		case 'h':
			ShowHint();
			break;
                case 'a':
                        ShowHistory();
                        break;
                case '?':
                        ShowHelp();
                        break;
                case '!':
                        Display(GetSolution());
                        break;
                case 'q':
                        quit = true;
                        break;
                default:
                        cout << "\nUnknown flag. Ignored.\n";
                        break;
	}
	return quit;
}

void Game::Score(vector<char> thisGuess, int & correct, int & position)
{
	correct = 0;
	position = 0;
	
	int i;
	
	for(i = 0; i< howManyLetters; i++)
	{
		int howManyInGuess = count(thisGuess.begin(), thisGuess.end(), alpha[i]);
		int howManyInAnswer = count(solution.begin(), solution.end(), alpha[i]);
		correct += min(howManyInGuess, howManyInAnswer);
	}

	for(i = 0; i< howManyPositions; i++)
	{
		if(thisGuess[i] == solution[i])
			position++;
	}
}

void Game::ShowHelp()
{
	cout << "\t-h Hint\n\t-s Show history\n\t-? Help\n\t-q quit\n";
	cout << endl;
}

void Game::ShowHistory()
{
	for(
		vector<Guess>::const_iterator it = history.begin();
		it != history.end();
		it++	
		)
	{
		it->Display();
	}
}

void Game::ShowHint()
{
	if(hintCtr < howManyPositions)
	{
		cout << "\nHINT!! Position " << hintCtr + 1;
		cout << ": " << solution[hintCtr] <<endl;
		hintCtr++;
	}
}


#ifndef GAME_H
#define GAME_H


#include "def0514.h"
#include "Guess.h"
class Guess;

class Game
{
	public:
		Game();
		~Game(){}
		void Display(vector<char> charVec) const;
		bool HandleFlag(char flag);
		bool IsValid(char theChar) const;
		vector<char> GetSolution() const;
		void Play();
		void Score(vector<char> thisGuess, int & correct, int & position);
		void ShowHint();
		void ShowHistory();
		void ShowHelp();

	private:
		vector<char> solution;
		vector<Guess> history;
		int hintCtr;
		int howManyLetters;
		int howManyPositions;
		bool duplicates;
		int round;
};
#endif

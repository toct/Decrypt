#ifndef GUESS_H
#define GUESS_H

#include "def0514.h"

class Guess
{
	public:
		Guess(vector<char> theGuess, int howMnayRight, int howManyInPosition);
		~Guess(){}
		pair<int, int> GetScore() const{ return score;}
		vector<char> GetString() const {return myString;}			
		void Display() const;

	private:
		vector<char> myString;
		pair<int, int> score;
};
#endif

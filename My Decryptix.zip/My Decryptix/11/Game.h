#ifndef GAME_H
#define GAME_H

#include "defvals.h"
#include "Guess.h"
#include "SmartString.h"


class Guess;
class Decrypter;

class Game
{
	public:
		Game();
		~Game(){}
		
		void Play();

		static int howManyLetters;
		static int howManyPositions;

	private:
		void DisplayTime(int secs);
		bool VerifyComputerChoice();
		bool duplicates;

		Decrypter *pDecrypter;
};

#endif

#include "Game.h"
#include "defvals.h"
#include "Decrypter.cpp"
#include "Human.cpp"
#include "Computer.cpp"


int Game::howManyLetters = 0;
int Game::howManyPositions = 0;

Game::Game()
{
	for(;;)
	{
		//got user's prefence ofr how many possible letters
		while(howManyLetters < minLetters || howManyLetters > maxLetters)
		{
			cout << "How many letters? (";
			cout << minLetters << " - " << maxLetters << "): ";
			cin >> howManyLetters;  
			if(howManyLetters < minLetters || howManyLetters > maxLetters)	
			{
				cout << "please enter a number between ";
				cout << minLetters << " and "<< maxLetters <<endl;
			}	
		}
		
		//get user's preference for how many slots (positions)
		while( howManyPositions < minPos || howManyPositions > maxPos)
		{
			cout << "How many positions? (";
			cout << minPos << " - " << maxPos << "): ";
			cin >> howManyPositions;
			if(howManyPositions < minPos || howManyPositions > maxPos)
			{
				cout << "please enter a number between ";
				cout << minPos << " and " << maxPos <<endl;
			}
		}

		char choice = ' ';
		while(choice != 'y' && choice != 'n')
		{
			cout << "Allow duplicates (y/n)? ";
			cin >> choice;
		}
		
		duplicates = choice == 'y'?true:false;

		if(!duplicates && howManyPositions > howManyLetters)
		{
			cout << "\nI can't put "<< howManyLetters;
			cout << " letters in " << howManyPositions;
			cout << " positions without duplicates! ";
			cout << " Please try again.\n\n";
			howManyPositions = 0;
			howManyLetters = 0;
			continue;
		}
		
		choice = ' ';
		while(choice != 'h' && choice != 'c')
		{
			cout << " Who guesses. (H)uman";
			cout << " or (C)omputer? (h/c)?  : ";
			cin >> choice;
		}
		
		bool ok = choice == 'h'?true:VerifyComputerChoice();
		if(ok)
			pDecrypter = new Human(duplicates);
		else
			pDecrypter = new Computer(duplicates);
		break;		
	}
}

void Game::DisplayTime(int totalSeconds)
{
	int totalDays = totalSeconds / SecondsInDay;
	int totalHours = totalSeconds / SecondsInHour;
	int totalMinutes = totalSeconds / SecondsInMinute;

	if(totalDays > 1)
		cout << totalDays <<" days! ";
	else if(totalHours > 1 )
        cout << totalHours << " hours! ";
	else if(totalMinutes > 1)
		cout << totalMinutes << " minutes. ";
	else
		cout << totalSeconds << " seconds! ";
}

void Game::Play()
{
	int start = time(NULL);

	pDecrypter->Play();

	//report elapsed time;
	int end = time(NULL);
	int totalSeconds = end - start;
	
	cout << "\nTotal elapsed time, this game: ";
	DisplayTime(totalSeconds);

	cout << "\n";

	howManyLetters = 0;
	howManyPositions = 0; 
}


bool Game::VerifyComputerChoice()
{
	int totalGuesses = 1;
	if(duplicates)
		for(int i = 0; i < howManyPositions; i++)
			totalGuesses *= howManyLetters;
	else
		for(
			int i = howManyLetters;
			i > howManyLetters - howManyPositions;
			i--			
			)
			totalGuesses *= i;
		
	int totalSeconds = totalGuesses / GUESSES_PRE_SECOND;
	
	if(totalSeconds > 2)
	{
		cout << "\n\nYou are asking me to guess ";
		cout << "from a possible " << totalGuesses;
		cout << " combinations. ";

		cout << "\nI can get through about ";
		cout << GUESSES_PRE_SECOND;
		cout << " guesses pre seconds. ";
		cout << "If the puzzle is tough,";
		cout << "\na single guess could take me more than ";

		DisplayTime(totalSeconds);
	
		char confirm = ' ';
		while(confirm != 'y' && confirm != 'n')
		{
			cout << "\n\nAre you sure (y/n)? ";
			cin >> confirm;
		}
        
        if(confirm == 'n')
        {
                howManyPositions = 0;
                howManyLetters = 0;
                return false;
        }
	}
	else
	{
		cout << " Choosing among " << totalGuesses;
		cout << " possible combinations...\n\n";
	}
	return true;
}

#if !defined STORABLE_H // #if !defined    &    ifndef   前者支持多个编译检查
#define STORABLE_H

#include "defineValues.h"

class Reader;
class Writer;
class Guess;

class Storable  
{
public:
	Storable(){}
    virtual ~Storable(){}
    Storable(Reader &) {}
	virtual void Write(Writer &) const = 0;
};

class Reader
{
public:
	Reader(char * filename):fin(filename,ios::binary){}
	virtual ~Reader(){fin.close();}
	virtual Reader & operator >> (int &);
	virtual Reader & operator >> (const int &);
	virtual Reader & operator >> (char &);
	virtual Reader & operator >> (char *&);
	virtual Reader & operator >> (bool &);
	virtual Reader & operator >> (vector<char> &);

private:
	ifstream fin;
};

class Writer
{
public:
	Writer(char * filename):fout(filename, ios::binary){};
	virtual ~Writer() {fout.close(); }
	virtual Writer & operator << (int &);
	virtual Writer & operator << (const int &);
	virtual Writer & operator << (char &);
	virtual Writer & operator << (char *&);
	virtual Writer & operator << (const char *&);
	virtual Writer & operator << (bool &);
	virtual Writer & operator << (const bool &);
	virtual Writer & operator << (const vector<char> &);

private:
	ofstream fout;
};

#endif 

#ifndef SMARTSTRING_H
#define SMARTSTRING_H

#include "SmartChar.h"

class Guess;


class SmartString  
{
public:
	SmartString(bool dupes);
	SmartString(Reader& rdr);
	virtual	~SmartString();

	bool CanEliminateCharacters	(const Guess& theGuess);  //试图删除字符
	bool GetNext();
	vector<char> GetString();
	bool RemoveCurrentCharacters();
	bool RemoveCurrentCharactersInEveryPosition();
	void Write(Writer& wrtr) const;

private:
	void ForceCharacters(const Guess & theGuess);  //试图查看其是否可辨认必然存在于答案中的字符
	int	 CountForcedInGuess(const Guess & theGuess);
	int	 CountUniqueLettersInGuess(const Guess & theGuess);
	bool In(vector <char> vec, char target) const;

	vector<char>			deadCharacters;  //不可能存在任何位置    不指定位置
	bool					duplicates;
	vector<char>			forcedCharacters; //已知的 存在的字符向量    不指定位置
	vector<SmartChar>		myString;
};
#endif 

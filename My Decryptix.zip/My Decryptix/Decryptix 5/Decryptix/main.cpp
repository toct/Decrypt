//
//  main.cpp
//  Decryptix
//
//  Created by li.guibin on 2017/3/15.
//  Copyright © 2017年 li.guibin. All rights reserved.
//
#include <fstream>
#include "def0514.h"
#include "Game.h"

int main() {
    bool hh;
    
    char file1[] = "file1";
    ifstream fin(file1,ios::binary);
    fin.read( (char*) &hh, sizeof(bool));
    
    cout<< "Decryptix. (c)Copyright 1999 Liberty Associates,";
    cout<< "Inc. Version 0.3\n\n"<<endl;
    
    bool playAgain = true;
    while(playAgain)
    {
        char choice = ' ';
        Game theGame;
        theGame.Play();
        
        cout<<"\nThe anwser: ";
        theGame.GetSolution().Display();
        cout<< "\n\n"<<endl;
        
        while(choice != 'n' || choice != 'y')
        {
            cout<< "\nPlay again (y/n): ";
            cin >> choice;
        }
        playAgain = choice == 'y'?true:false;
    }
    return 0;
}
